<?php

namespace GT3\ThemesCore\Customizer;

trait Defaults_Trait {
	protected $defaults = array(
		
	);
}
